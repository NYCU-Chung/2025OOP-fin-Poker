#include "Game.h"

int main() {
    Game g;
    g.start();
    return 0;
}
